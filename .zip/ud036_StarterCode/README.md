#Movie Trailer website 

Website that displays a movie poster image and when clicked, displays the corresponding movie trailer.

#Usage

type 'python entertainment_center.py'.  This will create an **HTML** file named: fresh_tomatoes.html. Open this file with your favorite web browser and enjoy!

#License

Created for the Full-stack developer nano degree.